#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/sched.h>
#include <linux/cred.h>
asmlinkage long nitinhello(void)
{
        printk("Hello Everyone\n");
        return 0;
}
